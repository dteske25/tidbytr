load("encoding/json.star", "json")
load("render.star", "render")
def main(config):
    data = json.decode(config.get("payload_json") or "{}")
    display = data.get("display") or {}
    time_text = display.get("time") or "--:--"
    blink_time = display.get("blinkTime") or time_text
    date_text = display.get("date") or "--- --"

    return render.Root(
        delay = 500,
        child = render.Stack(
            children = [
                render.Box(width = 64, height = 2, color = "#0b5"),
                render.Padding(
                    pad = (display.get("timeX") or 7, 2, 0, 0),
                    child = render.Animation(
                        children = [
                            render.Text(content = time_text, font = "10x20", color = "#fff"),
                            render.Text(content = blink_time, font = "10x20", color = "#fff"),
                        ],
                    ),
                ),
                render.Padding(
                    pad = (7, 22, 0, 0),
                    child = render.Text(content = date_text, color = "#28f"),
                ),
                render.Padding(
                    pad = (51, 23, 0, 0),
                    child = render.Text(content = display.get("period") or "", font = "tom-thumb", color = "#9AB"),
                ),
                render.Padding(
                    pad = (2, 30, 0, 0),
                    child = render.Box(width = 60, height = 1, color = "#014"),
                ),
            ],
        ),
    )
